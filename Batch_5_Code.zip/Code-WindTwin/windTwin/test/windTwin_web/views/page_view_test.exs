defmodule WindTwinWeb.PageViewTest do
  use WindTwinWeb.ConnCase, async: true
end
