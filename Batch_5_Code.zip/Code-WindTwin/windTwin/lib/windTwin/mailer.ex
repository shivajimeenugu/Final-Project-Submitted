defmodule WindTwin.Mailer do
  use Swoosh.Mailer, otp_app: :windTwin
end
