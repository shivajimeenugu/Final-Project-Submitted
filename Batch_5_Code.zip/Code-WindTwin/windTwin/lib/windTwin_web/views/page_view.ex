defmodule WindTwinWeb.PageView do
  use WindTwinWeb, :view
end
